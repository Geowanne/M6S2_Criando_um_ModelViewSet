from rest_framework.serializers import ModelSerializer

from reserva.models import Reserva
from base.models import Contato  


class AgendamentoModelSeralizer(ModelSerializer):
    class Meta:
        model = Reserva
        fields = '__all__'

class ContatoModelSeralizer(ModelSerializer):
    class Meta:
        model = Contato
        fields = '__all__'        