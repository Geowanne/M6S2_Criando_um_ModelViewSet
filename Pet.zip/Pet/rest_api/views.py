from django.shortcuts import render

from rest_framework.decorators import api_view
from rest_framework.response import Response 
from rest_framework.viewsets import ModelViewSet
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated

from reserva.models import Reserva
from base.models import Contato
from rest_api.serializers import AgendamentoModelSeralizer,ContatoModelSeralizer

class AgendamentoModelViewSet(ModelViewSet):
    queryset = Reserva.objects.all()
    serializer_class = AgendamentoModelSeralizer
    # permission_classes = [TokenAuthentication]
    # authentication_classes = [IsAuthenticated]

@api_view(['GET', 'POST'])
def hello_world(request):
    if request.method == 'POST':
        return Response({'message': f'Hello, {request.data.get("name")}'})
    
    return Response({'helo': 'World API'})

# API Contato
class ContatoModelViewSet(ModelViewSet):
    queryset = Contato.objects.all()
    serializer_class = ContatoModelSeralizer
    # permission_classes = [TokenAuthentication]
    # authentication_classes = [IsAuthenticated]

@api_view(['GET', 'POST'])
def contato_api(request):
    if request.method == 'POST':
        return Response({'message': f'Contat, {request.data.get("name")}'})
    
    return Response({'contat': 'World API'})
